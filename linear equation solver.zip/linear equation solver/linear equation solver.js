let solveEquation = function() {
	try {
		let userInput = document.getElementById("equationInput").value;
		let myRegex = /[\d(?=x)\s+\s\d\s=\s\d]/ig;

		for(var i=0; i<userInput.length; i++) {
			if (userInput.match(myRegex)) {
				let a = userInput[0];
				let b = userInput[5];
				let c = userInput[9];
				
				let output = (c-b) / a;
				document.getElementById("outputLabel").innerHTML = output;
			} else {
				alert("Please enter a linear equation in the format 'ax + b = c'.");
			}
		}
	} catch (error) {
		console.error(error);
	}
}

